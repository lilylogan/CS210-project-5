# flood-fill

Flood fill (introduction to recursion)

Count the chambers in a grid by filling each chamber in a grid
in which each cell is initially emtpy or a wall.  

Project for CS 210 at University of Oregon, an ACM CS1 course
equivalent to CS 161 at other Oregon colleges and universities.
Accompanies week 5 chapter in
[open text in progress]( 
https://uo-cs-oer.github.io/CS210-text/intro.html
).

Liberal open source license (CC-by-SA); fork and adapt! 
